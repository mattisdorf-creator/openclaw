OpenClaw AutoPlay — quick install (single‑player)

Contents of this ZIP:
- run_autoplay_install.sh  — helper: copies JARs and tries to download Baritone
- install.sh               — developer helper (source)
- fabric-autoplay/         — mod source (if you want to build locally)
- baritone-*.jar           — (only present if CI produced a build or download succeeded)

Quick user steps (2 minutes):
1) Extract ZIP and run: ./run_autoplay_install.sh 1.21.11
2) Start Minecraft with Fabric profile for 1.21.11
3) Open Singleplayer world — the mod auto‑starts the Baritone script `autoplay`

If the mod does not activate:
- Ensure `~/.minecraft/mods` contains a Baritone Fabric jar and the OpenClaw mod jar.
- In‑game chat: type `#script autoplay` to test Baritone manually.
- If you need help, run these commands and paste the output in the support chat:
  - ls -la ~/.minecraft/mods
  - rg -i 'openclaw|baritone' ~/.minecraft/logs/latest.log || true

Notes:
- If you want the truly one‑click experience, allow me to upload a CI‑built JAR when the workflow succeeds and I'll post the download link.
- Use this only on singleplayer or servers where you have permission (Anti‑cheat / bans may apply).
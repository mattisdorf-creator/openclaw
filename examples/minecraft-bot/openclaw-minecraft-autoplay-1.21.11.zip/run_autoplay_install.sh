#!/usr/bin/env bash
set -euo pipefail

# Installer helper for the OpenClaw AutoPlay PoC (single‑player).
# What it does:
# - Ensures ~/.minecraft/mods exists
# - Attempts to download a compatible Baritone Fabric JAR (best‑effort)
# - Copies any provided JARs from the ZIP into ~/.minecraft/mods
# - Prints final manual steps for the user

MC_VERSION="${1:-1.21.11}"
MODS_DIR="$HOME/.minecraft/mods"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "OpenClaw AutoPlay installer — Ziel MC version: $MC_VERSION"
mkdir -p "$MODS_DIR"

# copy any included jars (openclaw mod source/jar may not be present if CI didn't build it)
shopt -s nullglob
for f in "$HERE"/*.jar; do
  echo "Copying $f -> $MODS_DIR/"
  cp -v "$f" "$MODS_DIR/"
done
shopt -u nullglob

# best-effort: try GitHub releases for Baritone and pick a fabric asset
echo "Versuche Baritone (Fabric) automatisch herunterzuladen..."
API_URL="https://api.github.com/repos/cabaletta/baritone/releases"
ASSET_URL=""

if command -v curl >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
  ASSET_URL=$(curl -s "$API_URL" | jq -r --arg ver "$MC_VERSION" '.[] .assets[] | select(.name | test("fabric"; "i")) | .browser_download_url' | head -n1 || true)
  if [ -z "$ASSET_URL" ]; then
    ASSET_URL=$(curl -s "$API_URL" | jq -r '.[] .assets[] | select(.name | test("baritone.*jar"; "i")) | .browser_download_url' | head -n1 || true)
  fi
fi

if [ -n "$ASSET_URL" ]; then
  echo "Gefunden: $ASSET_URL"
  curl -fL -o "$MODS_DIR/$(basename "$ASSET_URL")" "$ASSET_URL"
  echo "Baritone heruntergeladen nach $MODS_DIR/$(basename "$ASSET_URL")"
else
  echo "Kein automatischer Baritone‑Download möglich. Bitte lade ein Fabric‑Jar von:" >&2
  echo "  https://github.com/cabaletta/baritone/releases" >&2
fi

cat <<EOF

Fertig — nächste Schritte:
1) Starte Minecraft (Profile: Fabric $MC_VERSION) einmal.
2) Kopiere alle JARs aus $MODS_DIR in dein Minecraft mods‑Ordner (falls noch nicht passiert).
   (Default: ~/.minecraft/mods)
3) Starte Minecraft → Singleplayer → Welt öffnen.
   Du solltest im Chat sehen: "OpenClaw AutoPlay: Mod geladen — Autostart in ~2s"
4) Falls nichts passiert: öffne Chat und tippe: #script autoplay

Wenn du möchtest, sende mir die Ausgabe von:
  ls -la ~/.minecraft/mods
  rg -i 'openclaw|baritone' ~/.minecraft/logs/latest.log || true

EOF